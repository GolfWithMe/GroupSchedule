<?php
/**
* @copyright (C) 2015 iJoomla, Inc. - All rights reserved.
* @license GNU General Public License, version 2 (http://www.gnu.org/licenses/gpl-2.0.html)
* @author iJoomla.com <webmaster@ijoomla.com>
* @url https://www.jomsocial.com/license-agreement
* The PHP code portions are distributed under the GPL license. If not otherwise stated, all images, manuals, cascading style sheets, and included JavaScript *are NOT GPL, and are released under the IJOOMLA Proprietary Use License v1.0
* More info at https://www.jomsocial.com/license-agreement
*/
defined('_JEXEC') or die();
?>

    <div class="joms-blankslate"><?php echo 'Waiting Your Response' ?></div>
 <?php if ($schedule) {  ?>   
    <ul class="joms-list--event">
    <?php foreach ($schedule as $row) { ?>
    	<?php 
			$gsid=$row->gsid;
			//group schedule
			$gsModel = CFactory::getModel('groupschedule');
			$gsData = $gsModel->getScheduleDetails($gsid);
			?>
        <li class="joms-media--event">
            <div class="joms-media__body">
                <small style="height:15px; font-weight:bold">&raquo; <a class="joms-button--link" href="<?php echo CRoute::_('index.php?option=com_community&view=groupschedule&gsid='.$gsid); ?>"><?php echo $gsData->CourseName; ?></a></small>
            </div>
        </li>
    <?php } ?>
</ul>
<?php } else { ?>
    <small>Not Avaialable</small>
<?php } ?>

    <small><a class="joms-button--link" href="<?php echo CRoute::_('index.php?option=com_community&view=groupschedule&task=recresponse'); ?>"><?php echo 'Show All'; ?></a></small>
    
   <div class="joms-blankslate"><?php echo 'Your Upcoming' ?></div>

    <?php if ($useraccept) {  ?>   
    
    <ul class="joms-list--event">
    <?php foreach ($useraccept as $row) { ?>
    	<?php 
			$gsid=$row->id;
			//group schedule
			$gsModel = CFactory::getModel('groupschedule');
			$gsData = $gsModel->getScheduleDetails($gsid);
			?>
        <li class="joms-media--event">
            <div class="joms-media__body">
            <?php
				$accbutton=0;
				$scheduleDate = $gsModel->getGroupScheduleDate($gsid);
				foreach ( $scheduleDate as $rowdate ) {
					//members request sent
					//$smem= $gsModel->getGroupScheduleMemberCount($gsid);
					//$accmem= $gsModel->getGroupScheduleAcceptCount($gsid,$rowdate->id,2);
					//$acctotmem= $gsModel->getGroupScheduleAcceptCount($gsid,$rowdate->id);
					$accda= $gsModel->getDateAcceptCount($gsid,$rowdate->id);
					
					if($accda->actmem>0) { 
					?>
                    	<small style="height:15px; font-weight:bold">&raquo; <?php echo $rowdate->sdate; ?> - <a class="joms-button--link" href="<?php echo CRoute::_('index.php?option=com_community&view=groupschedule&gsid='.$gsid.'&did='.$rowdate->id); ?>"><?php echo $gsData->CourseName; ?></a></small>
              	<?php } ?>
           <?php } ?>
            </div>
        </li>
    <?php } ?>
</ul>
<?php } else { ?>
    <small>Not Avaialable</small>
<?php } ?>

<?php /* ?>
<div class="joms-blankslate"><?php echo 'You Might Be Interested' ?></div>
	<?php if ($mightbeschedule) {  ?>   
        <ul class="joms-list--event">
        <?php foreach ($mightbeschedule as $row) { ?>
            <?php 
                //$gsid=$row->id;
                //group schedule
                //$gsModel = CFactory::getModel('groupschedule');
                //$gsData = $gsModel->getScheduleDetails($gsid);
                ?>
            <li class="joms-media--event">
                <div class="joms-media__body">
                    <small style="height:15px; font-weight:bold">&raquo; <?php echo $row->Name; ?></small>
                </div>
            </li>
        <?php } ?>
    </ul>
    <?php } else { ?>
        <small>Not Avaialable</small>
    <?php } ?>
    <small><a class="joms-button--link" href="<?php echo CRoute::_('index.php?option=com_community&view=groupschedule&task=closerequest'); ?>"><?php echo 'Show All'; ?></a></small>
<?php */ ?>
   
   